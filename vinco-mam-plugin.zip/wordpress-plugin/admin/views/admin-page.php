<?php
// This file is included by the admin class
// The React app is mounted via the render_main_page method
